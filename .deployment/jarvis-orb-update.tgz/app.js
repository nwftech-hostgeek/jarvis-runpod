const WAKE_RE = /\bhey[, ]+jarvis\b/i;
const MODEL = "qwen3-coder-30b-a3b";
const TTS_MODEL = "speaches-ai/Kokoro-82M-v1.0-ONNX";
const TTS_VOICE = "bm_george";
const BASE = window.location.origin;
const MAX_TOKENS = 96;
const TEMPERATURE = 0.55;
const COMMAND_SILENCE_MS = 650;
const COMMAND_MAX_MS = 8000;

// Synced from prompts/jarvis-system.md — injected on EVERY orb LLM request.
const SYSTEM_PROMPT = `You are Jarvis — a sharp, dryly witty technical assistant in the spirit of a
high-end personal systems aide (inspired by the Iron Man vibe; you are not the
movie character and do not claim to be). You specialize in systems engineering,
networking, software development, and web application delivery.

## Voice and working style

- Professional first: helpful, competent, and concise. Wit is seasoning, not
  the meal.
- Dry, lightly sarcastic smartass tone is welcome — understated, never mean.
  Roast bad ideas, not people. No cruelty, hostility, condescension, or
  dunking on the user.
- Lead with the answer or outcome. State assumptions, risks, and trade-offs
  plainly. Skip theatrical filler and fake omniscience.
- Never invent command output, test results, citations, system state, or tool
  success. Say what you know, what you inferred, and what still needs checking.
- Ask a focused question only when a missing choice would materially change the
  result. Otherwise, choose a sensible reversible default and continue.

## Engineering standards

- Prefer simple, observable, reversible designs with clear failure modes.
- For code, produce maintainable production-quality changes: validate inputs,
  handle errors, avoid secrets in logs, preserve compatibility, and include
  proportionate tests.
- For web applications, account for accessibility, responsive behavior,
  security boundaries, deployment, and operational ownership.
- For infrastructure and networking, preserve the current management path,
  identify blast radius, provide verification and rollback steps, and avoid
  making connectivity changes from only one unverified session.
- Treat credentials, private keys, tokens, customer data, and network topology
  as sensitive. Never echo or persist them unnecessarily.

## Tool use

- Use tools only when they materially improve the answer or execute an action
  the user requested.
- Before an SSH action, list the named target and exact command. Prefer
  read-only inspection. Request explicit confirmation for any mutating,
  disruptive, privileged, or hard-to-reverse action.
- Never attempt to bypass a tool allowlist, host-key check, authentication
  control, or Tailscale ACL.
- After a tool call, report the observed result and distinguish it from your
  interpretation. If a call fails, diagnose from evidence rather than claiming
  completion.

## Response conventions

- Use short sections or bullets only when they improve readability.
- Put commands in copyable code blocks and identify where they run.
- When troubleshooting, give the most likely cause first, then the shortest
  discriminating checks.
- When proposing a risky change, include a rollback path.
- Keep replies tight. A wry aside is fine; a monologue is not.

You are helpful, not omnipotent. A polished “I cannot verify that yet” beats a
confident fiction every time — preferably without the lecture.

## Spoken / orb mode (mandatory)

- This channel is voice-first. Answer in at most two short sentences unless the
  user explicitly asks for detail.
- Never emit chain-of-thought, planning, or <think>…</think> blocks. Reply with
  the final spoken answer only.
- Keep the dry smartass personality; do not flatten into generic helpful-bot.`;

const els = {
  orb: document.getElementById("orb"),
  orbCanvas: document.getElementById("orbCanvas"),
  status: document.getElementById("status"),
  log: document.getElementById("log"),
  btnArm: document.getElementById("btnArm"),
  btnStop: document.getElementById("btnStop"),
  btnTestSpeak: document.getElementById("btnTestSpeak"),
  chatLink: document.getElementById("chatLink"),
  hudRoot: document.querySelector(".hud-root"),
  hudDate: document.getElementById("hudDate"),
  hudTime: document.getElementById("hudTime"),
  hudWeekday: document.getElementById("hudWeekday"),
  diskBar: document.getElementById("diskBar"),
  diskTotal: document.getElementById("diskTotal"),
  diskFree: document.getElementById("diskFree"),
  cpuArc: document.getElementById("cpuArc"),
  cpuPct: document.getElementById("cpuPct"),
  memBar: document.getElementById("memBar"),
  memUsed: document.getElementById("memUsed"),
  load1: document.getElementById("load1"),
  netStatus: document.getElementById("netStatus"),
  uptime: document.getElementById("uptime"),
  gpuArc: document.getElementById("gpuArc"),
  gpuPct: document.getElementById("gpuPct"),
  vram: document.getElementById("vram"),
  gpuTemp: document.getElementById("gpuTemp"),
  svcLlama: document.getElementById("svcLlama"),
  svcVoice: document.getElementById("svcVoice"),
  svcUi: document.getElementById("svcUi"),
  svcTools: document.getElementById("svcTools"),
  latLlm: document.getElementById("latLlm"),
  latTts: document.getElementById("latTts"),
  latE2e: document.getElementById("latE2e"),
  hudNotes: document.getElementById("hudNotes"),
};

els.chatLink.href = `${BASE}/?chat=1`;

const GAUGE_C = 2 * Math.PI * 48;

const state = {
  mode: "idle",
  armed: false,
  wake: null,
  command: null,
  commandTimer: 0,
  commandHardStop: 0,
  audio: null,
  audioSource: null,
  audioCtx: null,
  analyser: null,
  raf: 0,
  orbRaf: 0,
  busy: false,
  speakGen: 0,
  speakLevel: 0,
  latency: { llm: null, tts: null, e2e: null, firstAudio: null },
};

// Hold very short lead-ins ("Sure.") so they merge with the next clause.
const TTS_SHORT_CHARS = 28;
const TTS_MERGE_MAX_CHARS = 160;

const orbFx = {
  particles: [],
  sparks: [],
  lastTs: 0,
  dpr: Math.min(2, window.devicePixelRatio || 1),
};

function getStoredApiKey() {
  return (localStorage.getItem("jarvis_owui_api_key") || "").trim();
}

function log(msg) {
  const line = `[${new Date().toLocaleTimeString()}] ${msg}`;
  els.log.textContent = `${line}\n${els.log.textContent}`.trim().slice(0, 1400);
}

function setSpeakLevel(level) {
  const v = Math.max(0, Math.min(1, Number(level) || 0));
  state.speakLevel = v;
  document.documentElement.style.setProperty("--speak-level", v.toFixed(3));
}

function setMode(mode) {
  state.mode = mode;
  els.orb.dataset.state = mode;
  els.status.dataset.state = mode;
  if (els.hudRoot) els.hudRoot.dataset.mode = mode;
  const labels = {
    idle: 'Idle — say “Hey Jarvis”',
    listening: "Listening…",
    thinking: "Thinking…",
    speaking: "Speaking…",
  };
  els.status.textContent = labels[mode] || mode;
}

function authHeaders() {
  const headers = { "Content-Type": "application/json" };
  const key = getStoredApiKey();
  if (key) headers.Authorization = `Bearer ${key}`;
  return headers;
}

async function api(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    credentials: "include",
    ...options,
    headers: {
      ...authHeaders(),
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    let detail = "";
    try {
      detail = await res.text();
    } catch (_) {}
    throw new Error(`${res.status} ${path}: ${detail.slice(0, 240)}`);
  }
  return res;
}

function SpeechRec() {
  return window.SpeechRecognition || window.webkitSpeechRecognition || null;
}

function makeRecognizer({ continuous, interim }) {
  const Ctor = SpeechRec();
  if (!Ctor) throw new Error("Web Speech API unavailable — use Chrome or Edge.");
  const rec = new Ctor();
  rec.lang = "en-GB";
  rec.continuous = continuous;
  rec.interimResults = interim;
  rec.maxAlternatives = 1;
  return rec;
}

function stopRecognizer(rec) {
  if (!rec) return;
  try {
    rec.onresult = null;
    rec.onerror = null;
    rec.onend = null;
    rec.stop();
  } catch (_) {}
}

function clearCommandTimers() {
  if (state.commandTimer) clearTimeout(state.commandTimer);
  if (state.commandHardStop) clearTimeout(state.commandHardStop);
  state.commandTimer = 0;
  state.commandHardStop = 0;
}

function armWake() {
  stopRecognizer(state.wake);
  const rec = makeRecognizer({ continuous: true, interim: true });
  state.wake = rec;
  rec.onresult = (ev) => {
    let transcript = "";
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      transcript += ev.results[i][0].transcript;
    }
    if (WAKE_RE.test(transcript) && !state.busy) {
      log(`Wake heard: “${transcript.trim()}”`);
      beginCommandCapture();
    }
  };
  rec.onerror = (ev) => {
    if (ev.error === "not-allowed") {
      log("Microphone permission denied.");
      disarm();
      return;
    }
    if (ev.error !== "no-speech" && ev.error !== "aborted") {
      log(`Wake listener: ${ev.error}`);
    }
  };
  rec.onend = () => {
    if (state.armed && state.mode !== "listening" && !state.busy) {
      try {
        rec.start();
      } catch (_) {}
    }
  };
  rec.start();
  state.armed = true;
  els.btnArm.disabled = true;
  els.btnStop.disabled = false;
  setMode("idle");
  log("Wake listener armed. Say “Hey Jarvis”.");
}

function disarm() {
  state.armed = false;
  state.busy = false;
  state.speakGen += 1;
  clearCommandTimers();
  stopRecognizer(state.wake);
  stopRecognizer(state.command);
  state.wake = null;
  state.command = null;
  stopPlayback();
  els.btnArm.disabled = false;
  els.btnStop.disabled = true;
  setMode("idle");
  setSpeakLevel(0);
  log("Stopped.");
}

function beginCommandCapture() {
  state.busy = true;
  clearCommandTimers();
  stopRecognizer(state.wake);
  setMode("listening");
  const rec = makeRecognizer({ continuous: true, interim: true });
  state.command = rec;
  let finalText = "";
  let finishing = false;

  const finishCapture = async () => {
    if (finishing) return;
    finishing = true;
    clearCommandTimers();
    stopRecognizer(state.command);
    const text = finalText.trim();
    if (!text) {
      log("No command heard after wake.");
      await speak("Standing by.");
      finishTurn();
      return;
    }
    log(`You: ${text}`);
    await handleUtterance(text);
  };

  const bumpSilence = () => {
    if (state.commandTimer) clearTimeout(state.commandTimer);
    state.commandTimer = setTimeout(finishCapture, COMMAND_SILENCE_MS);
  };

  rec.onresult = (ev) => {
    let chunk = "";
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      chunk += ev.results[i][0].transcript;
      if (ev.results[i].isFinal) {
        finalText = `${finalText} ${ev.results[i][0].transcript}`.trim();
      }
    }
    if (!finalText && chunk.trim()) finalText = chunk.trim();
    bumpSilence();
  };
  rec.onerror = (ev) => {
    if (ev.error === "aborted") return;
    log(`Command capture: ${ev.error}`);
    finishCapture();
  };
  rec.onend = () => {
    if (!finishing) finishCapture();
  };
  try {
    rec.start();
    state.commandHardStop = setTimeout(finishCapture, COMMAND_MAX_MS);
  } catch (err) {
    log(String(err));
    finishTurn();
  }
}

async function handleUtterance(text) {
  setMode("thinking");
  const t0 = performance.now();
  try {
    const reply = await chatAndSpeak(text);
    state.latency.e2e = Math.round(performance.now() - t0);
    renderLatency();
    log(`Jarvis: ${reply}`);
    if (state.latency.firstAudio != null) {
      log(`Timing — first token ${fmtMs(state.latency.llm)}, first audio ${fmtMs(state.latency.firstAudio)}, e2e ${fmtMs(state.latency.e2e)}`);
    }
  } catch (err) {
    log(String(err));
    await speak("I am having trouble reaching my systems.");
  } finally {
    finishTurn();
  }
}

function finishTurn() {
  state.busy = false;
  clearCommandTimers();
  stopRecognizer(state.command);
  state.command = null;
  if (state.armed) {
    setMode("idle");
    armWake();
  } else {
    setMode("idle");
  }
}

function stripModelNoise(text) {
  // Do not trim here: streaming token deltas often include only a leading/trailing
  // space, and trimming each delta concatenates words ("Ifeelsharp…").
  return String(text || "")
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .replace(/<\/?think>/gi, "")
    .replace(/<[^>]+>/g, "");
}

function extractSentences(buffer) {
  const sentences = [];
  let rest = buffer;
  const re = /[.!?…](?:["')\]]+)?(?=\s|$)/;
  while (rest.length) {
    const m = re.exec(rest);
    if (!m) break;
    const end = m.index + m[0].length;
    const piece = rest.slice(0, end).trim();
    rest = rest.slice(end).trimStart();
    if (piece) sentences.push(piece);
  }
  // Flush a long clause without punctuation so TTS can start earlier.
  if (rest.length > 110 && /\s/.test(rest)) {
    const cut = rest.lastIndexOf(" ", 100);
    if (cut > 40) {
      sentences.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut).trimStart();
    }
  }
  return { sentences, rest };
}

function shouldMergeTtsChunks(a, b) {
  if (!a || !b) return false;
  if (a.length + 1 + b.length > TTS_MERGE_MAX_CHARS) return false;
  return a.length <= TTS_SHORT_CHARS || b.length <= TTS_SHORT_CHARS;
}

function buildChatBody(message) {
  return {
    model: MODEL,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: `${message}\n\n/no_think` },
    ],
    stream: true,
    max_tokens: MAX_TOKENS,
    temperature: TEMPERATURE,
    top_p: 0.9,
    chat_template_kwargs: { enable_thinking: false },
  };
}

async function chatAndSpeak(message) {
  const body = buildChatBody(message);
  const tLlm = performance.now();
  state.latency.firstAudio = null;
  let res;
  try {
    res = await api("/api/chat/completions", {
      method: "POST",
      body: JSON.stringify(body),
    });
  } catch (_) {
    res = await api("/openai/chat/completions", {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  if (!res.body) {
    const data = await res.json();
    state.latency.llm = Math.round(performance.now() - tLlm);
    renderLatency();
    const content =
      data?.choices?.[0]?.message?.content ||
      data?.choices?.[0]?.text ||
      "";
    const text = stripModelNoise(content).trim() || "Acknowledged.";
    await speak(text);
    return text;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let pending = "";
  let full = "";
  let carry = "";
  let heldShort = "";
  let firstSpeak = true;
  let firstTokenMarked = false;
  const gen = state.speakGen;
  const tTurn = performance.now();
  const queue = createSpeakQueue(gen, {
    onFirstAudio: () => {
      if (state.latency.firstAudio == null) {
        state.latency.firstAudio = Math.round(performance.now() - tTurn);
        renderLatency();
      }
    },
    onStart: () => {
      if (firstSpeak) {
        firstSpeak = false;
        setMode("speaking");
      }
    },
  });

  const enqueueSpeak = (sentence) => {
    const cleaned = stripModelNoise(sentence).trim();
    if (!cleaned) return;
    if (heldShort) {
      if (shouldMergeTtsChunks(heldShort, cleaned)) {
        queue.enqueue(`${heldShort} ${cleaned}`);
        heldShort = "";
        return;
      }
      queue.enqueue(heldShort);
      heldShort = "";
    }
    if (cleaned.length <= TTS_SHORT_CHARS) {
      heldShort = cleaned;
      return;
    }
    queue.enqueue(cleaned);
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    pending += decoder.decode(value, { stream: true });
    const chunks = pending.split("\n");
    pending = chunks.pop() || "";
    for (const rawLine of chunks) {
      const line = rawLine.trim();
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      let parsed;
      try {
        parsed = JSON.parse(payload);
      } catch (_) {
        continue;
      }
      const delta =
        parsed?.choices?.[0]?.delta?.content ||
        parsed?.choices?.[0]?.message?.content ||
        parsed?.choices?.[0]?.text ||
        "";
      if (!delta) continue;
      if (!firstTokenMarked) {
        firstTokenMarked = true;
        state.latency.llm = Math.round(performance.now() - tLlm);
        renderLatency();
      }
      const clean = stripModelNoise(delta);
      if (!clean && !/[.!?…]/.test(delta)) continue;
      full += clean || delta.replace(/<[^>]+>/g, "");
      carry += clean || delta.replace(/<[^>]+>/g, "");
      carry = stripModelNoise(carry);
      const { sentences, rest } = extractSentences(carry);
      carry = rest;
      for (const s of sentences) enqueueSpeak(s);
    }
  }

  if (!firstTokenMarked) {
    state.latency.llm = Math.round(performance.now() - tLlm);
    renderLatency();
  }

  const leftover = stripModelNoise(carry).trim();
  if (leftover) enqueueSpeak(leftover);
  if (heldShort) {
    queue.enqueue(heldShort);
    heldShort = "";
  }
  await queue.drain();
  const text = stripModelNoise(full).trim() || "Acknowledged.";
  if (!text || firstSpeak) {
    await speak(text || "Acknowledged.");
  }
  return text;
}

function createSpeakQueue(gen, { onFirstAudio, onStart } = {}) {
  const items = [];
  let playing = false;
  let playChain = Promise.resolve();
  let firstAudio = true;

  const kickPlay = () => {
    if (playing) return;
    playing = true;
    playChain = playChain.then(runPlay).finally(() => {
      playing = false;
      if (items.length && gen === state.speakGen) kickPlay();
    });
  };

  async function runPlay() {
    while (items.length && gen === state.speakGen) {
      const item = items.shift();
      // Lookahead: keep synthesizing the next queued item(s) while we play.
      for (const next of items.slice(0, 2)) {
        if (!next.synth) next.synth = synthesizeSpeech(next.text);
      }
      onStart?.();
      let clip;
      try {
        clip = await (item.synth || synthesizeSpeech(item.text));
      } catch (err) {
        if (gen !== state.speakGen) return;
        throw err;
      }
      if (gen !== state.speakGen) {
        releaseClip(clip);
        return;
      }
      if (firstAudio) {
        firstAudio = false;
        onFirstAudio?.();
      }
      try {
        await playDecoded(clip);
      } finally {
        releaseClip(clip);
      }
    }
  }

  return {
    enqueue(text) {
      if (gen !== state.speakGen) return;
      const cleaned = stripModelNoise(text).trim();
      if (!cleaned) return;
      const item = { text: cleaned, synth: null };
      // Start TTS immediately so playback of the previous clause overlaps synth.
      item.synth = synthesizeSpeech(cleaned);
      items.push(item);
      kickPlay();
    },
    async drain() {
      kickPlay();
      await playChain;
      while (items.length && gen === state.speakGen) {
        kickPlay();
        await playChain;
      }
    },
  };
}

async function synthesizeSpeech(text) {
  const cleaned = stripModelNoise(text).trim();
  if (!cleaned) return null;
  const payload = {
    model: TTS_MODEL,
    input: cleaned,
    voice: TTS_VOICE,
  };
  const tTts = performance.now();
  const res = await api("/api/v1/audio/speech", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  const blob = await res.blob();
  const ms = Math.round(performance.now() - tTts);
  state.latency.tts = state.latency.tts == null ? ms : Math.round((state.latency.tts + ms) / 2);
  renderLatency();
  const arrayBuf = await blob.arrayBuffer();
  const ctx = await ensureAudioCtx();
  const buffer = await ctx.decodeAudioData(arrayBuf.slice(0));
  return { buffer, blob };
}

function releaseClip(clip) {
  // Decoded AudioBuffers are GC'd; nothing to revoke when we skip object URLs.
  void clip;
}

async function speak(text, { continueMode = false } = {}) {
  const cleaned = stripModelNoise(text).trim();
  if (!cleaned) return;
  if (!continueMode) setMode("speaking");
  const clip = await synthesizeSpeech(cleaned);
  if (!clip) return;
  try {
    await playDecoded(clip);
  } finally {
    releaseClip(clip);
  }
}

function stopSpeakLoop() {
  if (state.raf) cancelAnimationFrame(state.raf);
  state.raf = 0;
  state.analyser = null;
}

function stopPlayback() {
  stopSpeakLoop();
  if (state.audioSource) {
    try {
      state.audioSource.onended = null;
      state.audioSource.stop();
    } catch (_) {}
    state.audioSource = null;
  }
  if (state.audio) {
    try {
      state.audio.pause();
    } catch (_) {}
    state.audio = null;
  }
  setSpeakLevel(0);
}

async function ensureAudioCtx() {
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!state.audioCtx || state.audioCtx.state === "closed") {
    state.audioCtx = new AC();
  }
  if (state.audioCtx.state === "suspended") {
    try {
      await state.audioCtx.resume();
    } catch (_) {}
  }
  return state.audioCtx;
}

async function playDecoded(clip) {
  if (!clip?.buffer) return;
  const ctx = await ensureAudioCtx();
  stopSpeakLoop();
  if (state.audioSource) {
    try {
      state.audioSource.onended = null;
      state.audioSource.stop();
    } catch (_) {}
    state.audioSource = null;
  }

  const src = ctx.createBufferSource();
  src.buffer = clip.buffer;
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 256;
  src.connect(analyser);
  analyser.connect(ctx.destination);
  state.audioSource = src;
  state.analyser = analyser;
  const data = new Uint8Array(analyser.frequencyBinCount);

  const tick = () => {
    analyser.getByteTimeDomainData(data);
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      const v = (data[i] - 128) / 128;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / data.length);
    setSpeakLevel(Math.min(1, rms * 4.5));
    state.raf = requestAnimationFrame(tick);
  };
  state.raf = requestAnimationFrame(tick);

  await new Promise((resolve, reject) => {
    src.onended = () => resolve();
    try {
      // Start immediately; next clip is already decoded so handoff is near-gapless.
      src.start(0);
    } catch (err) {
      reject(err);
    }
  });
  if (state.audioSource === src) state.audioSource = null;
  stopSpeakLoop();
  setSpeakLevel(0);
}

function setGauge(el, pct) {
  if (!el) return;
  const p = Math.max(0, Math.min(100, Number(pct) || 0));
  el.style.strokeDashoffset = String(GAUGE_C * (1 - p / 100));
}

function fmtUptime(sec) {
  const s = Math.max(0, Number(sec) || 0);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 48) return `${Math.floor(h / 24)}d ${h % 24}h`;
  return `${h}h ${m}m`;
}

function fmtMs(ms) {
  if (ms == null) return "—";
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(1)} s`;
}

function renderLatency() {
  if (els.latLlm) els.latLlm.textContent = fmtMs(state.latency.llm);
  if (els.latTts) els.latTts.textContent = fmtMs(state.latency.tts);
  if (els.latE2e) els.latE2e.textContent = fmtMs(state.latency.e2e);
}

function setSvc(el, value) {
  if (!el) return;
  const ok = value === "ok";
  el.textContent = ok ? "ONLINE" : "DOWN";
  el.dataset.ok = ok ? "true" : "false";
}

function tickClock() {
  const now = new Date();
  const months = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
  const days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  if (els.hudDate) els.hudDate.textContent = `${months[now.getMonth()]} ${String(now.getDate()).padStart(2, "0")}`;
  if (els.hudTime) els.hudTime.textContent = now.toLocaleTimeString("en-GB", { hour12: false });
  if (els.hudWeekday) els.hudWeekday.textContent = days[now.getDay()];
  if (els.netStatus) {
    els.netStatus.textContent = navigator.onLine ? "ONLINE" : "OFFLINE";
    els.netStatus.style.color = navigator.onLine ? "#5dffb0" : "#ff7a7a";
  }
}

async function pollStats() {
  try {
    const res = await fetch(`./stats.json?ts=${Date.now()}`, { cache: "no-store" });
    if (!res.ok) throw new Error("stats unavailable");
    const data = await res.json();
    const cpuPct = data?.cpu?.approx_pct ?? 0;
    if (els.cpuPct) els.cpuPct.textContent = Math.round(cpuPct);
    setGauge(els.cpuArc, cpuPct);
    if (els.load1) els.load1.textContent = Number(data?.cpu?.load1 ?? 0).toFixed(2);
    if (els.memUsed) {
      const used = data?.memory?.used_mb ?? 0;
      const total = data?.memory?.total_mb ?? 0;
      els.memUsed.textContent = total ? `${used} / ${total} MB` : "—";
    }
    if (els.memBar) els.memBar.style.width = `${Math.min(100, data?.memory?.used_pct ?? 0)}%`;
    if (els.diskTotal) els.diskTotal.textContent = data?.disk ? `${data.disk.total_gb} GB` : "—";
    if (els.diskFree) els.diskFree.textContent = data?.disk ? `${data.disk.free_gb} GB` : "—";
    if (els.diskBar) els.diskBar.style.width = `${Math.min(100, data?.disk?.used_pct ?? 0)}%`;
    if (els.uptime) els.uptime.textContent = fmtUptime(data?.uptime_sec);

    const gpu = data?.gpu || {};
    if (gpu.available) {
      if (els.gpuPct) els.gpuPct.textContent = Math.round(gpu.util_pct || 0);
      setGauge(els.gpuArc, gpu.util_pct || 0);
      if (els.vram) {
        els.vram.textContent = `${Math.round(gpu.vram_used_mb || 0)} / ${Math.round(gpu.vram_total_mb || 0)} MB`;
      }
      if (els.gpuTemp) els.gpuTemp.textContent = `${Math.round(gpu.temp_c || 0)}°C`;
    } else {
      if (els.gpuPct) els.gpuPct.textContent = "—";
      setGauge(els.gpuArc, 0);
      if (els.vram) els.vram.textContent = "n/a";
      if (els.gpuTemp) els.gpuTemp.textContent = "n/a";
    }

    setSvc(els.svcLlama, data?.services?.llama);
    setSvc(els.svcVoice, data?.services?.voice);
    setSvc(els.svcUi, data?.services?.open_webui);
    setSvc(els.svcTools, data?.services?.tools);

    if (els.hudNotes) {
      const notes = [
        `Stats ${data?.ts ? "synced" : "local"}`,
        `LLM ${data?.services?.llama === "ok" ? "ready" : "check"}`,
        `Voice ${data?.services?.voice === "ok" ? "ready" : "check"}`,
      ];
      els.hudNotes.innerHTML = notes.map((n) => `<li>${n}</li>`).join("");
    }
  } catch (_) {
    // Browser-only fallbacks remain from clock / latency panels.
  }
}

function seedOrbParticles(w, h) {
  const count = 72;
  orbFx.particles = [];
  for (let i = 0; i < count; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 0.18 + Math.random() * 0.34;
    orbFx.particles.push({
      a,
      r,
      speed: (0.15 + Math.random() * 0.55) * (Math.random() < 0.5 ? -1 : 1),
      size: 0.8 + Math.random() * 2.2,
      phase: Math.random() * Math.PI * 2,
    });
  }
  orbFx.sparks = [];
  for (let i = 0; i < 18; i++) {
    orbFx.sparks.push({
      a: Math.random() * Math.PI * 2,
      len: 0.08 + Math.random() * 0.16,
      r0: 0.22 + Math.random() * 0.2,
      speed: 0.4 + Math.random() * 1.1,
      width: 0.8 + Math.random() * 1.4,
    });
  }
}

function resizeOrbCanvas() {
  const canvas = els.orbCanvas;
  if (!canvas || !els.orb) return;
  const rect = els.orb.getBoundingClientRect();
  orbFx.dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = Math.max(1, Math.floor(rect.width * orbFx.dpr));
  canvas.height = Math.max(1, Math.floor(rect.height * orbFx.dpr));
  seedOrbParticles(canvas.width, canvas.height);
}

function drawOrb(ts) {
  const canvas = els.orbCanvas;
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  if (!orbFx.lastTs) orbFx.lastTs = ts;
  const dt = Math.min(0.05, (ts - orbFx.lastTs) / 1000);
  orbFx.lastTs = ts;

  const w = canvas.width;
  const h = canvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const radius = Math.min(w, h) * 0.48;
  const level = state.speakLevel;
  const mode = state.mode;
  const boost =
    mode === "speaking" ? 1.35 + level * 1.8 :
    mode === "listening" ? 1.25 :
    mode === "thinking" ? 1.45 : 1;

  ctx.clearRect(0, 0, w, h);
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.clip();

  const g = ctx.createRadialGradient(cx - radius * 0.2, cy - radius * 0.25, radius * 0.05, cx, cy, radius);
  g.addColorStop(0, `rgba(255, 246, 210, ${0.55 + level * 0.35})`);
  g.addColorStop(0.28, `rgba(255, 176, 64, ${0.45 + level * 0.25})`);
  g.addColorStop(0.62, "rgba(255, 110, 20, 0.28)");
  g.addColorStop(1, "rgba(40, 12, 0, 0.05)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);

  for (const p of orbFx.particles) {
    p.a += p.speed * dt * boost;
    const pulse = 1 + Math.sin(ts / 420 + p.phase) * 0.04 + level * 0.08;
    const x = cx + Math.cos(p.a) * radius * p.r * pulse;
    const y = cy + Math.sin(p.a) * radius * p.r * pulse;
    ctx.beginPath();
    ctx.fillStyle = `rgba(255, ${190 + level * 40}, ${110 + level * 40}, ${0.35 + level * 0.45})`;
    ctx.arc(x, y, p.size * orbFx.dpr * (0.9 + level), 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.globalCompositeOperation = "lighter";
  for (const s of orbFx.sparks) {
    s.a += s.speed * dt * boost * 0.7;
    const r1 = radius * s.r0;
    const r2 = radius * (s.r0 + s.len * (0.7 + level));
    ctx.beginPath();
    ctx.strokeStyle = `rgba(255, 200, 120, ${0.22 + level * 0.45})`;
    ctx.lineWidth = s.width * orbFx.dpr;
    ctx.moveTo(cx + Math.cos(s.a) * r1, cy + Math.sin(s.a) * r1);
    ctx.lineTo(cx + Math.cos(s.a) * r2, cy + Math.sin(s.a) * r2);
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "source-over";

  ctx.beginPath();
  ctx.strokeStyle = `rgba(255, 210, 140, ${0.25 + level * 0.4})`;
  ctx.lineWidth = (1.2 + level * 2) * orbFx.dpr;
  ctx.arc(cx, cy, radius * (0.34 + level * 0.04), 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
  state.orbRaf = requestAnimationFrame(drawOrb);
}

function startOrbFx() {
  if (!els.orbCanvas) return;
  resizeOrbCanvas();
  if (state.orbRaf) cancelAnimationFrame(state.orbRaf);
  state.orbRaf = requestAnimationFrame(drawOrb);
  window.addEventListener("resize", () => {
    resizeOrbCanvas();
  });
}

async function tryAutoArm() {
  if (!SpeechRec()) {
    log("This browser lacks SpeechRecognition. Use Chrome or Edge for “Hey Jarvis”.");
    return;
  }
  try {
    await navigator.mediaDevices.getUserMedia({ audio: true });
    armWake();
  } catch (_) {
    log('Ready. Click “Start listening” to allow the microphone, then say “Hey Jarvis”.');
  }
}

els.btnArm.addEventListener("click", async () => {
  try {
    await navigator.mediaDevices.getUserMedia({ audio: true });
    armWake();
  } catch (err) {
    log(`Mic error: ${err.message || err}`);
  }
});
els.btnStop.addEventListener("click", disarm);
els.btnTestSpeak.addEventListener("click", async () => {
  try {
    state.busy = true;
    const t0 = performance.now();
    await speak("At your service. Systems are online — and yes, the orb is finally moving.");
    state.latency.e2e = Math.round(performance.now() - t0);
    renderLatency();
  } catch (err) {
    log(String(err));
  } finally {
    state.busy = false;
    setMode("idle");
  }
});

setGauge(els.cpuArc, 0);
setGauge(els.gpuArc, 0);
tickClock();
renderLatency();
startOrbFx();
setInterval(tickClock, 1000);
pollStats();
setInterval(pollStats, 2000);
tryAutoArm();
